package exception;

public class EmptyExecutionStack extends RuntimeException{
    public EmptyExecutionStack(){};
}
