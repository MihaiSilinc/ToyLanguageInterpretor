package exception;

public class ProgramException extends RuntimeException{
    public ProgramException(){}
}
