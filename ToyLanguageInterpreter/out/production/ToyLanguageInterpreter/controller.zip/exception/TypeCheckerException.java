package exception;

public class TypeCheckerException extends Exception{
    public TypeCheckerException(){}
    public TypeCheckerException(String message) {
        super(message);
    }
}
