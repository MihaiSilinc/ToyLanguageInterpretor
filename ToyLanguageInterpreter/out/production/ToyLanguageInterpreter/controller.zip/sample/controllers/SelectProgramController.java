package sample.controllers;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import model.statements.IStatement;

import controller.Controller;
import exception.TypeCheckerException;
import model.ProgramState;
import model.expressions.*;
import model.hashtable.IHashTable;
import model.hashtable.TypeEnvironment;
import model.statements.*;
import model.types.*;
import model.values.BoolValue;
import model.values.IntValue;
import model.values.StringValue;
import repository.Repository;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;


public class SelectProgramController implements Initializable{
    @FXML
    private Button executeButton;
    @FXML
    private ListView<IStatement> programsListView;

    private List<IStatement> statements;

    private RunProgramController runProgramController;

    public void setRunProgramController(RunProgramController runProgramController)
    {
        this.runProgramController = runProgramController;
    }

    private void populateList()
    {
        statements = new ArrayList();

        IStatement ex1 = new CompoundStatement(new VariableDeclarationStatement("v", new IntType()),
                new CompoundStatement( new AssignStatement("v", new ValueExpression(new IntValue(2))),
                        new PrintStatement(new VariableExpression("v"))));

        statements.add(ex1);

        IStatement ex2 = new CompoundStatement( new VariableDeclarationStatement("a",new IntType()),
                new CompoundStatement(new VariableDeclarationStatement("b",new IntType()),
                        new CompoundStatement(new AssignStatement("a", new ArithmeticExpression('+',new ValueExpression(new IntValue(2)),new
                                ArithmeticExpression('*',new ValueExpression(new IntValue(3)), new ValueExpression(new IntValue(5))))),
                                new CompoundStatement(new AssignStatement("b",new ArithmeticExpression('+',new VariableExpression("a"), new
                                        ValueExpression(new IntValue(1)))), new PrintStatement(new VariableExpression("b"))))));

        statements.add(ex2);

        IStatement ex3 = new CompoundStatement(new VariableDeclarationStatement("a",new BoolType()),
                new CompoundStatement(new VariableDeclarationStatement("v", new IntType()),
                        new CompoundStatement(new AssignStatement("a", new ValueExpression(new BoolValue(true))),
                                new CompoundStatement(new IfStatement(  new VariableExpression("a"),
                                        new AssignStatement("v",new ValueExpression(new IntValue(2))),
                                        new AssignStatement("v", new ValueExpression(new IntValue(3)))),
                                        new PrintStatement(new VariableExpression("v"))))));

        statements.add(ex3);

        IStatement ex4 = new CompoundStatement(new VariableDeclarationStatement("varf", new StringType()),
                new CompoundStatement(new AssignStatement("varf", new ValueExpression(new StringValue("E:\\IONUT\\Semestrul 3\\Advanced Programming Methods\\src\\test.in"))),
                        new CompoundStatement(new OpenReadFileStatement(new VariableExpression("varf")),
                                new CompoundStatement(new VariableDeclarationStatement("varc", new IntType()),
                                        new CompoundStatement(new ReadFileStatement(new VariableExpression("varf"), "varc"),
                                                new CompoundStatement(new PrintStatement(new VariableExpression("varc")),
                                                        new CompoundStatement(new ReadFileStatement(new VariableExpression("varf"), "varc"),
                                                                new CompoundStatement(new PrintStatement(new VariableExpression("varc")),
                                                                        new CloseReadFileStatement(new VariableExpression("varf"))))))))));

        statements.add(ex4);

        //if( ((2 < 3) and (3 >= 2)) or (2 == 3)))
        IStatement ex5 = new IfStatement(
                new LogicalExpression(new LogicalExpression(
                        new RelationalExpression(new ValueExpression(new IntValue(2)), new ValueExpression(new IntValue(3)), "<"),
                        new RelationalExpression(new ValueExpression(new IntValue(3)), new ValueExpression(new IntValue(2)), ">="), "and"),
                        new RelationalExpression(new ValueExpression(new IntValue(2)), new ValueExpression(new IntValue(3)), "=="),
                        "or"),
                new PrintStatement(new ValueExpression(new StringValue("OK!"))),
                new PrintStatement(new ValueExpression(new StringValue("NOT OK!"))));

        statements.add(ex5);

        //Ref int v;new(v,20);Ref Ref int a; new(a,v);print(v);print(a) - Exception, v is not a referneceType
        IStatement ex6 = new CompoundStatement(new VariableDeclarationStatement("v", new ReferenceType(new IntType())),
                new CompoundStatement(new NewStatement("v", new ValueExpression(new IntValue(20))),
                        new CompoundStatement(new VariableDeclarationStatement( "a", new ReferenceType(new ReferenceType(new IntType()))),
                                new CompoundStatement(new NewStatement("a", new VariableExpression("v")),
                                        new CompoundStatement(new PrintStatement(new VariableExpression("v")),
                                                new PrintStatement((new VariableExpression("a"))))))));

        statements.add(ex6);

        //Ref int v;new(v,20);Ref Ref int a; new(a,v); write(readHeap(v));write(readHeap(readHeap(a))+5)

        IStatement ex7 = new CompoundStatement(new VariableDeclarationStatement("v", new ReferenceType(new IntType())),
                new CompoundStatement(new NewStatement("v", new ValueExpression(new IntValue(20))),
                        new CompoundStatement(new VariableDeclarationStatement( "a", new ReferenceType(new ReferenceType(new IntType()))),
                                new CompoundStatement(new NewStatement("a", new VariableExpression("v")),
                                        new CompoundStatement(new PrintStatement(new ReadHeapExpression(new VariableExpression("v"))),
                                                new PrintStatement(new ArithmeticExpression('+',
                                                        new ReadHeapExpression(new ReadHeapExpression(new VariableExpression("a"))),
                                                        new ValueExpression(new IntValue(5)))))))));

        statements.add(ex7);

        //Ref int v;new(v,20);print(rH(v)); wH(v,30);print(rH(v)+5);

        IStatement ex8 = new CompoundStatement(new VariableDeclarationStatement("v", new ReferenceType(new IntType())),
                new CompoundStatement(new NewStatement("v", new ValueExpression(new IntValue(20))),
                        new CompoundStatement(new PrintStatement(new ReadHeapExpression(new VariableExpression("v"))),
                                new CompoundStatement(new WriteHeapStatement("v", new ValueExpression(new IntValue(30))),
                                        new PrintStatement(new ArithmeticExpression('+',
                                                new ReadHeapExpression(new VariableExpression("v")),
                                                new ValueExpression(new IntValue(5))))))));

        statements.add(ex8);

        //int v; v=4; (while (v>0) print(v);v=v-1);print(v)
        IStatement ex9 = new CompoundStatement(new VariableDeclarationStatement("v", new IntType()),
                new CompoundStatement(new AssignStatement("v", new ValueExpression(new IntValue(4))),
                        new CompoundStatement(new WhileStatement(/*new ValueExpression(new IntValue(2))*/new RelationalExpression(
                                new VariableExpression("v"), new ValueExpression(new IntValue(0)), ">"),
                                new CompoundStatement(new PrintStatement(new VariableExpression("v")),
                                        new AssignStatement("v",
                                                new ArithmeticExpression('-',
                                                        new VariableExpression("v"),
                                                        new ValueExpression(new IntValue(1)))))),
                                new PrintStatement(new VariableExpression("v")))));

        statements.add(ex9);

        //Ref int v;new(v,20);Ref Ref int a; new(a,v); new(v,30);print(rH(rH(a)))
        IStatement ex10 = new CompoundStatement(new VariableDeclarationStatement("v", new ReferenceType(new IntType())),
                new CompoundStatement(new NewStatement("v", new ValueExpression(new IntValue(20))),
                        new CompoundStatement(new VariableDeclarationStatement("a", new ReferenceType(new ReferenceType(new IntType()))),
                                new CompoundStatement(new NewStatement("a", new VariableExpression("v")),
                                        new CompoundStatement(new NewStatement("v", new ValueExpression(new IntValue(30))),
                                                new PrintStatement(new ReadHeapExpression(new ReadHeapExpression(new VariableExpression("a")))))))));

        statements.add(ex10);

        //int v; Ref int a; v=10;new(a,22);
        //fork(wH(a,30);v=32;print(v);print(rH(a)));
        //print(v);print(rH(a));

        IStatement ex11 = new CompoundStatement(new VariableDeclarationStatement("v", new IntType()),
                new CompoundStatement(new VariableDeclarationStatement("a", new ReferenceType(new IntType())),
                        new CompoundStatement(new AssignStatement("v", new ValueExpression(new IntValue(10))),
                                new CompoundStatement(new NewStatement("a", new ValueExpression(new IntValue(22))),
                                        new CompoundStatement(new ForkStatement(new CompoundStatement(new WriteHeapStatement("a", new ValueExpression(new IntValue(30))),
                                                new CompoundStatement(new AssignStatement("v", new ValueExpression(new IntValue(32))),
                                                        new CompoundStatement(new PrintStatement(new VariableExpression("v")),
                                                                new PrintStatement(new ReadHeapExpression(new VariableExpression("a"))))))),
                                                new CompoundStatement(new PrintStatement(new VariableExpression("v")),
                                                        new PrintStatement(new ReadHeapExpression(new VariableExpression("a")))))))));

        statements.add(ex11);

        IStatement ex12 = new CompoundStatement(new VariableDeclarationStatement("v", new IntType()),
                new CompoundStatement( new AssignStatement("v", new ValueExpression(new BoolValue(false))),
                        new PrintStatement(new VariableExpression("v"))));

        statements.add(ex12);

        programsListView.setItems(FXCollections.observableArrayList(statements));
    }

    private void executeButtonClicked()
    {
        int index = programsListView.getSelectionModel().getSelectedIndex();

        if(index < 0)
            return;

        String logFilePath = "E:\\IONUT\\Semestrul 3\\Advanced Programming Methods\\src\\Log\\logFile.txt";
        Repository repository = new Repository(logFilePath);
        IHashTable<String, IType> typeEnvironment = new TypeEnvironment();

        IStatement ex = programsListView.getItems().get(index);
        try{
            ex.typeCheck(typeEnvironment);
        }
        catch(TypeCheckerException e)
        {
            //Error Box
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("TypeCheck Error");
            alert.setHeaderText(null);
            alert.setContentText(e.toString());

            alert.showAndWait();
            return;
        }

        ProgramState program = new ProgramState(ex, repository.getHeap());
        repository.addProgram(program);
        Controller controller = new Controller(repository);
        controller.setDebugFlag(true);
        controller.setLogFlag(true);


        runProgramController.setController(controller);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        populateList();
        executeButton.setOnAction(e->executeButtonClicked());
    }
}
